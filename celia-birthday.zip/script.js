/* ============================================================
   script.js — Célia Birthday Experience
   Organizado por: Estado · Helpers · Frames · Animações
                   Renderização · Formulários · Submissão · Init
   ============================================================ */

'use strict';

/* ────────────────────────────────────────────────────────────
   ESTADO — fonte única de verdade
   ──────────────────────────────────────────────────────────── */
const state = {
  guestId:           '',      // lido de ?guest=xxx na URL
  guestName:         '',
  dinnerAttendance:  null,    // 'yes' | 'no'
  dinnerCompanions:  [],      // array de strings (max 3)
  dinnerCompanionChoice: 'no',
  afterAttendance:   null,    // 'yes' | 'no'
  afterCompanions:   [],
  afterCompanionChoice: 'no',
  submitted:         false,
  currentScene:      'scene-welcome'
};

/* ────────────────────────────────────────────────────────────
   HELPERS
   ──────────────────────────────────────────────────────────── */

/** Lê parâmetro da URL */
function getUrlParam(name) {
  return new URLSearchParams(window.location.search).get(name) || '';
}

/** Preenche elemento por ID com texto (seguro) */
function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/** Define href de link por ID */
function setHref(id, url) {
  const el = document.getElementById(id);
  if (el) el.href = url;
}

/** Mostra ou esconde um elemento hidden */
function setHidden(el, hidden) {
  if (!el) return;
  el.hidden = hidden;
}

/** Injeta config no DOM — textos editáveis centralizados em config.js */
function applyConfig() {
  document.title = SITE_CONFIG.pageTitle;

  // Welcome
  setText('w-eyebrow',    SITE_CONFIG.welcomeEyebrow);
  setText('w-title',      SITE_CONFIG.welcomeTitle);
  setText('w-message',    SITE_CONFIG.welcomeMessage);
  setText('w-submessage', SITE_CONFIG.welcomeSubmessage);
  document.getElementById('btn-yes').textContent = SITE_CONFIG.confirmYesLabel;
  document.getElementById('btn-no').textContent  = SITE_CONFIG.confirmNoLabel;

  // Reveal jantar
  setText('reveal-dinner-title', SITE_CONFIG.confirmedDinnerTitle);
  setText('reveal-dinner-msg',   SITE_CONFIG.confirmedDinnerMessage);
  setText('detail-dinner-label', SITE_CONFIG.cardDinnerLabel);
  setText('detail-dinner-venue', SITE_CONFIG.dinnerVenueName);
  setText('detail-dinner-date',  SITE_CONFIG.dinnerDateLabel);
  setText('detail-dinner-time',  SITE_CONFIG.dinnerTimeLabel);
  setText('detail-dinner-address', SITE_CONFIG.dinnerVenueAddress);
  setHref('link-dinner-maps', SITE_CONFIG.dinnerVenueMapsUrl);
  setText('detail-dinner-note', SITE_CONFIG.dinnerNote);

  // After question
  setText('after-q-eyebrow', SITE_CONFIG.afterQuestionTitle);
  setText('after-q-title',   SITE_CONFIG.afterQuestionSubtitle);
  setText('after-q-note',    SITE_CONFIG.afterQuestionNote);

  // Reveal after
  setText('after-reveal-title', SITE_CONFIG.afterTitle);
  setText('detail-after-label', SITE_CONFIG.cardAfterLabel);
  setText('detail-after-venue', SITE_CONFIG.afterVenueName);
  setText('detail-after-date',  SITE_CONFIG.afterDateLabel);
  setText('detail-after-time',  SITE_CONFIG.afterTimeLabel);
  setText('detail-after-address', SITE_CONFIG.afterVenueAddress);
  setHref('link-after-maps', SITE_CONFIG.afterVenueMapsUrl);
  setText('detail-after-note', SITE_CONFIG.afterNote);

  // Declined dinner
  setText('declined-title',   SITE_CONFIG.declinedDinnerTitle);
  setText('declined-message', SITE_CONFIG.declinedDinnerMessage);

  // Fecho after declined
  setText('close-title',   SITE_CONFIG.finalThankYouTitle);
  setText('close-message', SITE_CONFIG.finalThankYouMessage);

  // Final no
  setText('final-no-title',   SITE_CONFIG.finalNoTitle);
  setText('final-no-message', SITE_CONFIG.finalNoMessage);

  // Cartão final
  setText('screenshot-hint', '📸 ' + SITE_CONFIG.cardScreenshotNote);
  setText('final-message-text', SITE_CONFIG.finalThankYouMessage);

  // Cartão final — dados estáticos
  setText('fic-dinner-venue',   SITE_CONFIG.dinnerVenueName);
  setText('fic-dinner-date',    SITE_CONFIG.dinnerDateLabel);
  setText('fic-dinner-time',    SITE_CONFIG.dinnerTimeLabel);
  setText('fic-dinner-address', SITE_CONFIG.dinnerVenueAddress);
  setText('fic-after-venue',    SITE_CONFIG.afterVenueName);
  setText('fic-after-date',     SITE_CONFIG.afterDateLabel);
  setText('fic-after-time',     SITE_CONFIG.afterTimeLabel);
  setText('fic-after-address',  SITE_CONFIG.afterVenueAddress);

  // Kid photo
  const kidImg = document.getElementById('kid-photo');
  if (kidImg) kidImg.src = SITE_CONFIG.kidAfterImage;
}

/* ────────────────────────────────────────────────────────────
   FRAME ONDULADO — gerado programaticamente
   ──────────────────────────────────────────────────────────── */

/** Gera path SVG de moldura ondulada */
function buildWavyPath(width, height, padding, amplitude, wavelength) {
  const p  = padding;
  const a  = amplitude;
  const wl = wavelength;
  let d = '';

  // Top edge (left → right)
  d += `M ${p},${p} `;
  for (let x = p; x < width - p - wl / 2; x += wl) {
    d += `Q ${x + wl / 4},${p - a} ${x + wl / 2},${p} `;
    d += `Q ${x + wl * 3 / 4},${p + a} ${x + wl},${p} `;
  }

  // Right edge (top → bottom)
  d += `L ${width - p},${p} `;
  for (let y = p; y < height - p - wl / 2; y += wl) {
    d += `Q ${width - p + a},${y + wl / 4} ${width - p},${y + wl / 2} `;
    d += `Q ${width - p - a},${y + wl * 3 / 4} ${width - p},${y + wl} `;
  }

  // Bottom edge (right → left)
  d += `L ${width - p},${height - p} `;
  for (let x = width - p; x > p + wl / 2; x -= wl) {
    d += `Q ${x - wl / 4},${height - p + a} ${x - wl / 2},${height - p} `;
    d += `Q ${x - wl * 3 / 4},${height - p - a} ${x - wl},${height - p} `;
  }

  // Left edge (bottom → top)
  d += `L ${p},${height - p} `;
  for (let y = height - p; y > p + wl / 2; y -= wl) {
    d += `Q ${p - a},${y - wl / 4} ${p},${y - wl / 2} `;
    d += `Q ${p + a},${y - wl * 3 / 4} ${p},${y - wl} `;
  }

  d += 'Z';
  return d;
}

/** Inicializa um SVG frame pelo ID do path e do container */
function initFrame(pathId, containerId, { amplitude = 5, wavelength = 20, padding = 10 } = {}) {
  const pathEl      = document.getElementById(pathId);
  const containerEl = document.getElementById(containerId);
  if (!pathEl || !containerEl) return;

  const rect = containerEl.getBoundingClientRect();
  const w    = rect.width  || 300;
  const h    = rect.height || 500;

  // Ajustar SVG para cobrir o container
  const svg = pathEl.closest('svg');
  if (svg) {
    svg.setAttribute('viewBox', `0 0 ${w + 40} ${h + 40}`);
  }

  pathEl.setAttribute('d', buildWavyPath(w + 40, h + 40, padding, amplitude, wavelength));

  // Recalcular dasharray para o path completo
  try {
    const totalLength = pathEl.getTotalLength();
    if (totalLength) {
      pathEl.style.strokeDasharray  = totalLength;
      pathEl.style.strokeDashoffset = totalLength;
    }
  } catch (_) { /* Safari pode não suportar getTotalLength em todos os paths */ }
}

/** Inicializa todos os frames após a cena ser visível */
function initAllFrames() {
  requestAnimationFrame(() => {
    const wc = document.getElementById('scene-welcome');
    if (wc) {
      const fcEl = wc.querySelector('.frame-container');
      if (fcEl) initFrame('frame-path-welcome', 'scene-welcome',
        { amplitude: 6, wavelength: 22, padding: 18 });
    }
    initFrame('frame-path-dinner', 'dinner-detail-card',    { amplitude: 5, wavelength: 18, padding: 14 });
    initFrame('frame-path-after',  'scene-after-reveal',    { amplitude: 5, wavelength: 18, padding: 14 });
    initFrame('frame-path-final',  'final-invite-card',     { amplitude: 5, wavelength: 18, padding: 14 });
  });
}

/* ────────────────────────────────────────────────────────────
   PARTÍCULAS decorativas
   ──────────────────────────────────────────────────────────── */
function spawnParticles() {
  const container = document.getElementById('particles');
  if (!container) return;

  const items = ['♥', '✦', '·', '♥', '·', '✦', '♥', '·'];
  items.forEach((char, i) => {
    const p = document.createElement('span');
    p.className = 'particle particle--heart';
    p.textContent = char;
    p.style.cssText = `
      left: ${10 + (i * 12)}%;
      bottom: -20px;
      --duration: ${6 + Math.random() * 6}s;
      --delay: ${Math.random() * 8}s;
      color: ${['#f6d0dd','#b20d18','#e07090','#c9a87c'][i % 4]};
      opacity: 0;
      font-size: ${8 + Math.random() * 8}px;
    `;
    container.appendChild(p);
  });
}

/* ────────────────────────────────────────────────────────────
   CENAS — navegação
   ──────────────────────────────────────────────────────────── */

/** Transita para uma cena */
function showScene(sceneId, direction = 'forward') {
  const allScenes = document.querySelectorAll('.scene');
  const target    = document.getElementById(sceneId);
  if (!target) return;

  allScenes.forEach(s => s.classList.remove('active'));
  target.classList.add('active');
  state.currentScene = sceneId;

  // Scroll suave para o topo
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Revelar elementos com delay escalonado
  revealElements(target);

  // Inicializar frame SVG se necessário
  if (['scene-welcome', 'scene-dinner-reveal', 'scene-after-reveal', 'scene-final-card'].includes(sceneId)) {
    setTimeout(() => initAllFrames(), 200);
  }
}

/** Anima .reveal-up dentro de um container */
function revealElements(container) {
  const els = container.querySelectorAll('.reveal-up');
  els.forEach((el, i) => {
    el.classList.remove('visible');
    setTimeout(() => el.classList.add('visible'), 120 + i * 90);
  });
}

/* ────────────────────────────────────────────────────────────
   COMPANIONS — lógica de campos dinâmicos
   ──────────────────────────────────────────────────────────── */
const MAX_COMPANIONS = 3;

/** Cria campo de acompanhante */
function createCompanionField(index, placeholder) {
  const wrap = document.createElement('div');
  wrap.className = 'companion-field';
  wrap.innerHTML = `
    <input type="text" placeholder="${placeholder || 'Nome do acompanhante'} ${index + 1}"
      aria-label="Acompanhante ${index + 1}" maxlength="80" />
    <button type="button" class="companion-field__remove" aria-label="Remover acompanhante">×</button>
  `;
  const removeBtn = wrap.querySelector('.companion-field__remove');
  removeBtn.addEventListener('click', () => {
    wrap.remove();
    updateAddButtonVisibility(wrap.closest('.companions-wrap'));
  });
  return wrap;
}

/** Atualiza visibilidade do botão "Adicionar" */
function updateAddButtonVisibility(wrap) {
  if (!wrap) return;
  const list   = wrap.querySelector('.companion-list');
  const addBtn = wrap.querySelector('.btn--add');
  if (!list || !addBtn) return;
  const count = list.querySelectorAll('.companion-field').length;
  addBtn.hidden = count >= MAX_COMPANIONS;
}

/** Lê nomes de acompanhantes de uma lista */
function readCompanions(listId) {
  const list = document.getElementById(listId);
  if (!list) return [];
  return Array.from(list.querySelectorAll('input'))
    .map(i => i.value.trim())
    .filter(Boolean);
}

/* ────────────────────────────────────────────────────────────
   TOGGLE BUTTONS
   ──────────────────────────────────────────────────────────── */
function initToggle(yesId, noId, onToggle) {
  const yesBtn = document.getElementById(yesId);
  const noBtn  = document.getElementById(noId);
  if (!yesBtn || !noBtn) return;

  function activate(val) {
    yesBtn.classList.toggle('active', val === 'yes');
    noBtn.classList.toggle('active',  val === 'no');
    onToggle(val);
  }

  yesBtn.addEventListener('click', () => activate('yes'));
  noBtn.addEventListener('click',  () => activate('no'));
}

/* ────────────────────────────────────────────────────────────
   FORMULÁRIO JANTAR
   ──────────────────────────────────────────────────────────── */
function initDinnerForm() {
  const form        = document.getElementById('dinner-form');
  const nameInput   = document.getElementById('guest-name');
  const nameError   = document.getElementById('name-error');
  const companionsWrap = document.getElementById('dinner-companions');
  const companionList  = document.getElementById('dinner-companion-list');
  const addBtn         = document.getElementById('add-dinner-companion');

  // Toggle acompanhantes jantar
  initToggle('companion-yes', 'companion-no', (val) => {
    state.dinnerCompanionChoice = val;
    setHidden(companionsWrap, val !== 'yes');
    if (val !== 'yes') companionList.innerHTML = '';
  });

  // Adicionar campo de acompanhante
  addBtn.addEventListener('click', () => {
    const count = companionList.querySelectorAll('.companion-field').length;
    if (count >= MAX_COMPANIONS) return;
    const field = createCompanionField(count);
    companionList.appendChild(field);
    updateAddButtonVisibility(companionsWrap);
    field.querySelector('input').focus();
  });

  // Submissão
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = nameInput.value.trim();

    // Validação
    if (!name) {
      nameInput.classList.add('field__input--error');
      nameError.textContent = 'Por favor, escreve o teu nome.';
      nameInput.focus();
      return;
    }
    nameInput.classList.remove('field__input--error');
    nameError.textContent = '';

    state.guestName        = name;
    state.dinnerAttendance = 'yes';
    state.dinnerCompanions = state.dinnerCompanionChoice === 'yes'
      ? readCompanions('dinner-companion-list')
      : [];

    showScene('scene-dinner-reveal');
  });

  // Limpar erro em tempo real
  nameInput.addEventListener('input', () => {
    nameInput.classList.remove('field__input--error');
    nameError.textContent = '';
  });
}

/* ────────────────────────────────────────────────────────────
   FORMULÁRIO AFTER
   ──────────────────────────────────────────────────────────── */
function initAfterForm() {
  const afterCompanionsWrap = document.getElementById('after-companions');
  const afterCompanionList  = document.getElementById('after-companion-list');
  const addAfterBtn         = document.getElementById('add-after-companion');
  const submitAfterBtn      = document.getElementById('btn-submit-after');

  initToggle('after-companion-yes', 'after-companion-no', (val) => {
    state.afterCompanionChoice = val;
    setHidden(afterCompanionsWrap, val !== 'yes');
    if (val !== 'yes') afterCompanionList.innerHTML = '';
  });

  addAfterBtn.addEventListener('click', () => {
    const count = afterCompanionList.querySelectorAll('.companion-field').length;
    if (count >= MAX_COMPANIONS) return;
    const field = createCompanionField(count);
    afterCompanionList.appendChild(field);
    updateAddButtonVisibility(afterCompanionsWrap);
    field.querySelector('input').focus();
  });

  submitAfterBtn.addEventListener('click', () => {
    state.afterAttendance = 'yes';
    state.afterCompanions = state.afterCompanionChoice === 'yes'
      ? readCompanions('after-companion-list')
      : [];
    submitAllData();
  });
}

/* ────────────────────────────────────────────────────────────
   CARTÃO FINAL — populado dinamicamente
   ──────────────────────────────────────────────────────────── */
function populateFinalCard() {
  // Nome do convidado
  setText('fic-guest-name', state.guestName || '');

  // Acompanhantes do jantar
  const allCompanions = [
    ...state.dinnerCompanions,
    ...state.afterCompanions.filter(c => !state.dinnerCompanions.includes(c))
  ];
  const companionsText = allCompanions.length > 0
    ? '+ ' + allCompanions.join(', ')
    : '';
  setText('fic-companions-text', companionsText);

  // Bloco do after — só mostrar se confirmado
  const afterBlock = document.getElementById('fic-after-block');
  if (afterBlock) {
    setHidden(afterBlock, state.afterAttendance !== 'yes');
  }
}

/* ────────────────────────────────────────────────────────────
   SUBMISSÃO — Google Apps Script
   ──────────────────────────────────────────────────────────── */
async function submitAllData() {
  state.submitted = true;

  // Mostrar overlay de loading
  const overlay = document.getElementById('submission-overlay');
  setHidden(overlay, false);

  const payload = {
    inviteId:              state.guestId || 'direct',
    guestName:             state.guestName,
    dinnerAttendance:      state.dinnerAttendance || 'no',
    dinnerCompanionsCount: state.dinnerCompanions.length,
    dinnerCompanion1:      state.dinnerCompanions[0] || '',
    dinnerCompanion2:      state.dinnerCompanions[1] || '',
    dinnerCompanion3:      state.dinnerCompanions[2] || '',
    afterAttendance:       state.afterAttendance || 'no',
    afterCompanionsCount:  state.afterCompanions.length,
    afterCompanion1:       state.afterCompanions[0] || '',
    afterCompanion2:       state.afterCompanions[1] || '',
    afterCompanion3:       state.afterCompanions[2] || '',
    submittedAt:           new Date().toISOString(),
    userAgent:             navigator.userAgent.slice(0, 200),
    source:                window.location.href
  };

  // Verificar se a URL do Apps Script está configurada
  const scriptUrl = SITE_CONFIG.googleAppsScriptUrl;
  if (!scriptUrl || scriptUrl.startsWith('COLOCAR')) {
    console.warn('⚠️ URL do Google Apps Script não configurada. Os dados não serão guardados.');
    // Em desenvolvimento, simular delay e avançar na mesma
    await new Promise(r => setTimeout(r, 1000));
  } else {
    try {
      await fetch(scriptUrl, {
        method: 'POST',
        mode:   'no-cors', // Apps Script requer no-cors
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload)
      });
    } catch (err) {
      console.error('Erro ao submeter dados:', err);
      // Não bloquear a experiência por erro de rede
    }
  }

  // Esconder overlay
  setHidden(overlay, true);

  // Mostrar cartão final
  populateFinalCard();
  showScene('scene-final-card');
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — Welcome
   ──────────────────────────────────────────────────────────── */
function bindWelcomeButtons() {
  document.getElementById('btn-yes').addEventListener('click', () => {
    showScene('scene-dinner-form');
  });

  document.getElementById('btn-no').addEventListener('click', () => {
    state.dinnerAttendance = 'no';
    showScene('scene-declined-dinner');
    // Submeter resposta parcial (não vai ao jantar — pode ir ao after ainda)
  });
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — Reveal Jantar
   ──────────────────────────────────────────────────────────── */
function bindDinnerRevealButtons() {
  document.getElementById('btn-to-after-question').addEventListener('click', () => {
    showScene('scene-after-question');
  });
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — After Question (veio do jantar)
   ──────────────────────────────────────────────────────────── */
function bindAfterQuestionButtons() {
  document.getElementById('btn-after-yes').addEventListener('click', () => {
    state.afterAttendance = 'yes';
    showScene('scene-after-reveal');
  });

  document.getElementById('btn-after-no').addEventListener('click', () => {
    state.afterAttendance = 'no';
    submitAllData(); // submeter e mostrar fecho
    showScene('scene-after-declined');
  });
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — Declined Dinner
   ──────────────────────────────────────────────────────────── */
function bindDeclinedDinnerButtons() {
  document.getElementById('btn-to-after-nodinner').addEventListener('click', () => {
    showScene('scene-after-question-nodinner');
  });
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — After Question (não foi ao jantar)
   ──────────────────────────────────────────────────────────── */
function bindAfterQuestionNoDinnerButtons() {
  document.getElementById('btn-after-yes-nodinner').addEventListener('click', () => {
    state.afterAttendance = 'yes';
    showScene('scene-after-reveal');
  });

  document.getElementById('btn-after-no-nodinner').addEventListener('click', () => {
    state.afterAttendance = 'no';
    submitAllData();
    showScene('scene-final-no');
  });
}

/* ────────────────────────────────────────────────────────────
   BINDING DE BOTÕES — After Declined (só jantar confirmado)
   ──────────────────────────────────────────────────────────── */
function bindAfterDeclinedButtons() {
  const btn = document.getElementById('btn-show-card');
  if (btn) {
    btn.addEventListener('click', () => {
      populateFinalCard();
      showScene('scene-final-card');
    });
  }
}

/* ────────────────────────────────────────────────────────────
   INIT
   ──────────────────────────────────────────────────────────── */
function init() {
  // Ler ID do convidado da URL (?guest=xxx)
  state.guestId = getUrlParam('guest');

  // Aplicar todas as configs ao DOM
  applyConfig();

  // Partículas decorativas
  spawnParticles();

  // Inicializar bindings
  bindWelcomeButtons();
  initDinnerForm();
  bindDinnerRevealButtons();
  bindAfterQuestionButtons();
  initAfterForm();
  bindDeclinedDinnerButtons();
  bindAfterQuestionNoDinnerButtons();
  bindAfterDeclinedButtons();

  // Inicializar frames SVG da welcome screen
  setTimeout(() => initAllFrames(), 400);

  // Esconder loader com elegância
  const loader = document.getElementById('loader');
  if (loader) {
    setTimeout(() => {
      loader.classList.add('hidden');
      // Revelar cena de welcome
      const welcome = document.getElementById('scene-welcome');
      if (welcome) revealElements(welcome);
    }, 1600);
  }
}

// Aguardar DOM completo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
