# assets/ — Pasta de ficheiros de media

## Ficheiros necessários:

### kid-after.jpg ⭐ (OBRIGATÓRIO)
- Coloca aqui a foto da Célia em criança
- Dimensões ideais: 600×800px (portrait/vertical)
- Formato: JPG ou PNG
- O ficheiro deve chamar-se exatamente: kid-after.jpg
  (ou atualiza o caminho em config.js → kidAfterImage)

## Ficheiros opcionais:
- Podes adicionar imagens decorativas aqui e referenciar em config.js
