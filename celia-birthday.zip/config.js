// ============================================================
// config.js — Todas as variáveis e textos editáveis aqui
// ============================================================
// Edita este ficheiro para personalizar o site.
// NÃO é necessário tocar no HTML, CSS ou JS para a maioria das alterações.

const SITE_CONFIG = {

  // ── IDENTIDADE ───────────────────────────────────────────
  celebrantName:  "Célia Bizerra João",
  siteTitle:      "Aniversário da Célia",
  pageTitle:      "Célia Bizerra João · Birthday Experience",
  dressCode:      "Grown & Sexy",
  eventYear:      "2026",

  // ── WELCOME ──────────────────────────────────────────────
  welcomeEyebrow:     "Confirmação Final",
  welcomeTitle:       "Antes de revelar todos os detalhes desta celebração...",
  welcomeMessage:     "Como combinado, peço-lhe que confirme a sua presença final. O espaço e o horário do jantar serão revelados mediante confirmação.",
  welcomeSubmessage:  "Uma noite pensada com carinho, elegância e boas surpresas espera por si.",
  confirmYesLabel:    "Sim, vou",
  confirmNoLabel:     "Não vou",

  // ── FORMULÁRIO ───────────────────────────────────────────
  formTitle:             "Confirma a tua presença",
  formNamePlaceholder:   "O teu nome completo",
  formCompanionQuestion: "Vais com acompanhante(s)?",
  formCompanionYes:      "Sim",
  formCompanionNo:       "Não",
  formCompanionAddLabel: "+ Adicionar acompanhante",
  formCompanionLabel:    "Nome do acompanhante",
  formSubmitLabel:       "Confirmar presença",

  // ── JANTAR ───────────────────────────────────────────────
  // 🔧 EDITAR AQUI com os dados reais do restaurante
  dinnerDateLabel:    "18 de Abril de 2026",
  dinnerTimeLabel:    "20h00",
  dinnerVenueName:    "NOME DO RESTAURANTE",                     // ← editar
  dinnerVenueAddress: "Rua do Restaurante, nº 00, Lisboa",      // ← editar
  dinnerVenueMapsUrl: "https://maps.google.com/",               // ← editar com link Maps real
  dinnerNote:         "Chega com tempo, com energia boa e no mood certo para uma noite bonita, elegante e memorável.",

  // ── MENSAGENS JANTAR ─────────────────────────────────────
  confirmedDinnerTitle:   "Que bom ter-te comigo.",
  confirmedDinnerMessage: "A tua presença vai tornar esta celebração ainda mais especial. Abaixo encontras os detalhes do jantar — vem linda, confiante e pronta para brindar.",
  declinedDinnerTitle:    "Que pena...",
  declinedDinnerMessage:  "Gostava muito de te ter comigo neste jantar. Mas obrigada por me responderes — isso também é um gesto bonito.",
  declinedKissAndCheese:  "Um beijo e um queijo. 🧀💋",

  // ── AFTER ────────────────────────────────────────────────
  // 🔧 EDITAR AQUI com os dados reais do after
  afterQuestionTitle:     "Depois do jantar...",
  afterQuestionSubtitle:  "vais ao after?",
  afterQuestionNote:      "A noite pode não acabar já.",
  afterNoDinnerQuestion:  "Mesmo não indo ao jantar...",
  afterNoDinnerSubtitle:  "queres aparecer no after?",

  afterTitle:        "Então sim... agora posso contar-te.",
  afterDateLabel:    "19 de Abril de 2026",
  afterTimeLabel:    "HORÁRIO DO AFTER",                        // ← editar
  afterVenueName:    "NOME DO ESPAÇO DO AFTER",                // ← editar
  afterVenueAddress: "Rua do After, nº 00, Lisboa",            // ← editar
  afterVenueMapsUrl: "https://maps.google.com/",               // ← editar com link Maps real
  afterNote:         "Mais descontraído, mais ousado, mais festa. O mood continua: grown & sexy.",

  // ── FECHOS ───────────────────────────────────────────────
  finalThankYouTitle:   "Obrigada por confirmares.",
  finalThankYouMessage: "Mal posso esperar por celebrar contigo. Vemo-nos em breve.",
  finalOnlyAfterMsg:    "Mesmo sem jantar, fico feliz por te ver no after. Até lá!",
  finalNoTitle:         "Um beijo e um queijo",
  finalNoMessage:       "Mesmo não estando presente, obrigada pelo carinho e pela resposta. Sentes a minha falta — eu sei.",

  // ── CARTÃO FINAL (screenshot) ────────────────────────────
  cardScreenshotNote:  "Guarda este convite — faz screenshot para o teres sempre à mão.",
  cardDinnerLabel:     "Jantar de Aniversário",
  cardAfterLabel:      "After Party",

  // ── ASSETS ───────────────────────────────────────────────
  // 🔧 SUBSTITUIR pela foto "kid" real da Célia (coloca em assets/)
  kidAfterImage: "assets/kid-after.jpg",

  // ── INTEGRAÇÃO GOOGLE ────────────────────────────────────
  // 🔧 COLOCAR AQUI a URL do Web App do Google Apps Script após publicação
  googleAppsScriptUrl: "COLOCAR_AQUI_A_URL_DO_WEB_APP",

  // ── ADMIN ────────────────────────────────────────────────
  // 🔧 Chave de acesso à página admin — trocar por algo seguro
  adminSecretKey: "celia2026admin",

  // ── PALETA (referência; valores usados via CSS vars) ─────
  colors: {
    bg:          "#fff8f4",
    softPink:    "#fce8f0",
    red:         "#b20d18",
    deepRed:     "#7f0912",
    rose:        "#e07090",
    blush:       "#f6d0dd",
    cream:       "#fff8f4",
    black:       "#0a0a0f",
    gold:        "#c9a87c",
    white:       "#ffffff"
  }
};
